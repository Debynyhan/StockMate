package com.zybooks.stockmateinventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.security.MessageDigest;

public class UserAuthenticationActivity extends AppCompatActivity {

    // Instance of the database
    InventoryDatabaseHelper inventoryDatabaseHelper;

    // Cached view elements
    EditText usernameInput;
    EditText passwordInput;

    Button loginBtn;
    Button registerBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        inventoryDatabaseHelper = InventoryDatabaseHelper.getInstance(this);

        initializeViews();
        configureEventListeners();
    }

    private void initializeViews() {
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);

        loginBtn = findViewById(R.id.loginBtn);
        registerBtn = findViewById(R.id.registerBtn);

        // Disable both buttons by default
        loginBtn.setEnabled(false);
        registerBtn.setEnabled(false);
    }

    private void configureEventListeners() {
        usernameInput.addTextChangedListener(textWatcher);
        passwordInput.addTextChangedListener(textWatcher);

        loginBtn.setOnClickListener(view -> attemptLogin());
        registerBtn.setOnClickListener(view -> attemptRegistration());
    }

    /**
     * Watch for text changes and enable the login and register buttons when the username
     * and password fields have text in them, otherwise disable the buttons.
     */
    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
            boolean fieldsAreEmpty = getUsername().isEmpty() || getPassword().isEmpty();
            loginBtn.setEnabled(!fieldsAreEmpty);
            registerBtn.setEnabled(!fieldsAreEmpty);
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };


    public void attemptLogin() {
        if (!areCredentialsValid()) {
            displayErrorToast(getString(R.string.invalid_login));
            return;
        }

        try {
            boolean isLoggedIn = inventoryDatabaseHelper.validateUserCredentials(getUsername(), hash(getPassword()));

            if (isLoggedIn) {
                navigateToInventoryList();
            } else {
                displayErrorToast(getString(R.string.invalid_login));
            }
        } catch (Exception e) {
            displayErrorToast(getString(R.string.invalid_login));
        }
    }


    public void attemptRegistration() {
        if (!areCredentialsValid()) {
            displayErrorToast(getString(R.string.registration_error));
        }

        try {
            boolean userCreated = inventoryDatabaseHelper.addUser(getUsername(), hash(getPassword()));

            if (userCreated) {
                navigateToInventoryList();
            } else {
                displayErrorToast(getString(R.string.registration_error));
            }
        } catch (Exception e) {
            displayErrorToast(getString(R.string.registration_error));
        }
    }
    /**
     * Navigate to the inventory list screen
     */
    private void navigateToInventoryList() {
        Intent intent = new Intent(getApplicationContext(), InventoryListActivity.class);
        startActivity(intent);
    }

    private boolean areCredentialsValid() {
        return !getUsername().isEmpty() && !getPassword().isEmpty();
    }

    private String getUsername() {
        Editable username = usernameInput.getText();
        return username != null ? username.toString().trim().toLowerCase() : "";
    }

    private String getPassword() {
        Editable password = passwordInput.getText();
        return password != null ? password.toString().trim() : "";
    }


    /**
     * Hash the given password string using MD5
     *
     * @param password The given plain text password to hash
     * @return A hashed password as a string
     * @throws Exception If something went wrong, bail
     */
    private String hash(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(password.getBytes());
        byte[] digest = md.digest();
        StringBuffer sb = new StringBuffer();
        for (byte b : digest) {
            sb.append(String.format("%02x", b & 0xff));
        }

        return sb.toString();
    }

    /**
     * Helper function to show a Toast error
     *
     * @param errorMessage The error message to show
     */
    private void displayErrorToast(String errorMessage) {
        Toast toast = Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_SHORT);
        toast.show();
    }
}
