package com.zybooks.stockmateinventoryapp;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

class ItemHolder extends RecyclerView.ViewHolder {

    private Item mItem;
    private TextView mNameTextView;
    private EditText mQuantityView;

    private InventoryDatabaseHelper inventoryDatabaseHelper;

    private ImageButton mDecreaseQuantityBtnInline;
    private ImageButton mIncreaseQuantityBtnInline;
    ImageButton mItemActionsBtn;

    private static final String TAG = "ItemAdapter";

    public ItemHolder(View itemView, InventoryDatabaseHelper inventoryDb) {
        super(itemView);
        inventoryDatabaseHelper = inventoryDb;
        initViews(itemView);
        setupButtons();
    }

    private void initViews(View itemView) {
        mNameTextView = itemView.findViewById(R.id.itemName);
        mQuantityView = itemView.findViewById(R.id.editQuantity);
        mDecreaseQuantityBtnInline = itemView.findViewById(R.id.decreaseQuantityBtnInline);
        mIncreaseQuantityBtnInline = itemView.findViewById(R.id.increaseQuantityBtnInline);
        mItemActionsBtn = itemView.findViewById(R.id.itemActionsBtn);
    }

    private void setupButtons() {
        mDecreaseQuantityBtnInline.setOnClickListener(v -> decreaseQuantity());
        mIncreaseQuantityBtnInline.setOnClickListener(v -> increaseQuantity());
        mQuantityView.addTextChangedListener(new QuantityTextWatcher());
    }

    private void decreaseQuantity() {
        mItem.decreaseQuantityByOne();
        boolean updated = inventoryDatabaseHelper.updateItem(mItem);
        if (updated) {
            mQuantityView.setText(String.valueOf(mItem.getQuantity()));
        }
    }

    private void increaseQuantity() {
        mItem.increaseQuantityByOne();
        boolean updated = inventoryDatabaseHelper.updateItem(mItem);
        if (updated) {
            mQuantityView.setText(String.valueOf(mItem.getQuantity()));
        }
    }

    public void bind(Item item) {
        mItem = item;
        mNameTextView.setText(mItem.getName());
        mQuantityView.setText(String.valueOf(mItem.getQuantity()));
    }

    private int getItemQuantity() {
        String rawValue = mQuantityView.getText().toString().replaceAll("[^\\d.]", "").trim();
        int quantity = rawValue.isEmpty() ? 0 : Integer.parseInt(rawValue);
        return Math.max(quantity, 0);
    }

    public void setItemActionsBtnClickListener(View.OnClickListener listener) {
        mItemActionsBtn.setOnClickListener(listener);
    }

    private class QuantityTextWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
            mItem.setQuantity(getItemQuantity());
            boolean updated = inventoryDatabaseHelper.updateItem(mItem);
            Log.d(TAG, "Item quantity updated: " + updated);
        }

        @Override
        public void afterTextChanged(Editable s) {}
    }
}
