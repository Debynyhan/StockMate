package com.zybooks.stockmateinventoryapp;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class InventoryDatabaseHelper extends SQLiteOpenHelper {

    // Logcat tag
    private static final String LOG = "InventoryDatabaseHelper";

    // Database Version
    private static final int DATABASE_VERSION = 2;

    // Database Name
    private static final String DATABASE_NAME = "StockMate.db";

    // Singleton of the database
    private static InventoryDatabaseHelper sInventoryDatabaseHelper;

    /**
     * Factory method to get the singleton and create a new one if needed
     *
     * @param context The app's context
     * @return Inventory database
     */
    public static InventoryDatabaseHelper getInstance(Context context) {
        Log.i(LOG, "Get instance of database");
        if (sInventoryDatabaseHelper == null) {
            sInventoryDatabaseHelper = new InventoryDatabaseHelper(context);
        }
        return sInventoryDatabaseHelper;
    }

    /**
     * Make this class a singleton by marking the constructor as private
     *
     * @param context The app's context
     */
    private InventoryDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(UserContract.UserEntry.CREATE_USER_TABLE);
        db.execSQL(ItemContract.ItemEntry.CREATE_INVENTORY_TABLE);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + UserContract.UserEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + ItemContract.ItemEntry.TABLE_NAME);
        onCreate(db);
    }

    /**
     * Get all inventory items
     *
     * @return List of inventory items
     */
    public List<Item> getAllInventoryItems() {
        List<Item> items = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        String[] projection = {
                ItemContract.ItemEntry._ID,
                ItemContract.ItemEntry.COLUMN_NAME,
                ItemContract.ItemEntry.COLUMN_QUANTITY
        };

        Cursor cursor = db.query(
                ItemContract.ItemEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(ItemContract.ItemEntry._ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(ItemContract.ItemEntry.COLUMN_NAME));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(ItemContract.ItemEntry.COLUMN_QUANTITY));
            items.add(new Item(id, name, quantity));
        }

        cursor.close();

        return items;
    }



    /**
     * Create a new user - failing if the user already exists in the database.
     *
     * @param username The username of the user to create
     * @param password The hashed password of the user to create
     * @return `true` if user was created, `false` otherwise
     */
    public boolean addUser(String username, String password) {
        // check to see if user name exist
        if (isUsernameTaken(username)) {
            return false;
        }

        // Insert the user into the database
        long userId = insertNewUser(username, password);

        // Check if there was a user ID returned to indicate success.
        return userId != -1;
    }


    /**
     * Inserts a new user into the database.
     *
     * @param username The username of the user to create
     * @param password The hashed password of the user to create
     * @return The ID of the new user, or -1 if insertion failed
     */
    private long insertNewUser(String username, String password) throws SQLiteException {
        try {
            // Get an instance of the writable database using the helper method
            SQLiteDatabase db = getWritableDatabaseInstance();

            // Set the username and password values to insert into their columns
            ContentValues values = new ContentValues();
            values.put(UserContract.UserEntry.COLUMN_USERNAME, username);
            values.put(UserContract.UserEntry.COLUMN_PASSWORD, password);

            // Insert row
            return db.insertOrThrow(UserContract.UserEntry.TABLE_NAME, null, values);
        } catch (SQLiteException e) {
            // Log the error for debugging purposes
            Log.e(LOG, "Error inserting user into database", e);

            // Rethrow the exception to be handled by the calling code
            throw e;
        }
    }


    /**
     * Check if the given username and password match an existing user in the database.
     *
     * @param username The username to check
     * @param password The password to check
     * @return `true` if a matching user is found, `false` otherwise
     */
    public boolean validateUserCredentials(String username, String password) {
        // Get an instance of the writable database
        SQLiteDatabase db = getReadableDatabase();

        // Define the columns to retrieve
        String[] projection = {
                UserContract.UserEntry._ID
        };

        // Define the WHERE clause
        String selection = UserContract.UserEntry.COLUMN_USERNAME + " = ? AND " + UserContract.UserEntry.COLUMN_PASSWORD + " = ?";

        // Define the values for the WHERE clause
        String[] selectionArgs = { username, password };

        try {
            // Execute the query
            Cursor cursor = db.query(
                    UserContract.UserEntry.TABLE_NAME, // The table to query
                    projection,                     // The columns to retrieve
                    selection,                      // The WHERE clause
                    selectionArgs,                  // The values for the WHERE clause
                    null,                           // Group by
                    null,                           // Having
                    null                            // Order by
            );

            // Check if the cursor contains any rows
            return cursor.moveToFirst();

        } catch (Exception e) {
            Log.e(LOG, "Error querying database", e);
            return false;
        }
    }

    /**
     * Check to see if a user with the given username already exists in the database.
     *
     * @param username The given username to check
     * @return `true` if a user with that username exists, `false` otherwise
     */
    public boolean isUsernameTaken(String username) {
        Cursor cursor = getUserByUsername(username);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    /**
     * @param username The current user sign in
     * @return The user name
     */
    private Cursor getUserByUsername(String username) {
        SQLiteDatabase db = getReadableDatabase();
        String[] projection = {
                UserContract.UserEntry._ID,
                UserContract.UserEntry.COLUMN_USERNAME,
                UserContract.UserEntry.COLUMN_PASSWORD
        };
        String selection = UserContract.UserEntry.COLUMN_USERNAME + " = ?";

        String[] selectionArgs = {username};
        String limit = "1";

        return db.query(
                UserContract.UserEntry.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null,
                limit
        );
    }


    /**
     * Add an item to the database
     *
     * @param name     The name of the item
     * @param quantity The quantity of the item
     * @return Whether the item was successfully inserted into the database or not
     */
    public boolean addInventoryItem(String name, int quantity) {
        // Validate input
        if (name == null || name.isEmpty() || quantity < 0) {
            throw new IllegalArgumentException("Invalid arguments for addItem method");
        }

        // Get an instance of the writable database using the helper method
        SQLiteDatabase db = getWritableDatabaseInstance();

        // Set the values according to their columns using the helper method
        ContentValues values = createInventoryContentValues(name, quantity);

        // Insert row and close the database
        long itemId = -1;
        try {
            itemId = db.insert(ItemContract.ItemEntry.TABLE_NAME, null, values);
        } finally {
            db.close();
        }

        return itemId != -1;
    }

    /**
     * Get an instance of the writable database
     *
     * @return A writable instance of the database
     */
    private SQLiteDatabase getWritableDatabaseInstance() {
        return this.getWritableDatabase();
    }

    /**
     * Create ContentValues for the given item name and quantity
     * @param name     The name of the item
     * @param quantity The quantity of the item
     * @return ContentValues containing the item name and quantity
     */
    private ContentValues createInventoryContentValues(String name, int quantity) {
        ContentValues values = new ContentValues();
        values.put(ItemContract.ItemEntry.COLUMN_NAME, name);
        values.put(ItemContract.ItemEntry.COLUMN_QUANTITY, quantity);
        return values;
    }


    /**
     * Update an existing item
     *
     * @param item The item to update
     * @return Whether the item was successfully updated or not
     */
    public boolean updateItem(Item item) {
        // Get an instance of the writable database using the helper method
        SQLiteDatabase db = getWritableDatabaseInstance();

        // Set the values according to their columns
        ContentValues values = new ContentValues();
        values.put(ItemContract.ItemEntry.COLUMN_NAME, item.getName());
        values.put(ItemContract.ItemEntry.COLUMN_QUANTITY, item.getQuantity());

        // Update the item and check that it successfully updated
        int rowsUpdated = db.update(ItemContract.ItemEntry.TABLE_NAME, values, ItemContract.ItemEntry._ID + " = ?",
                new String[]{String.valueOf(item.getId())});

        return rowsUpdated > 0;
    }

    /**
     * Delete an item from the database
     *
     * @param item The item to delete
     * @return Whether the item was successfully deleted or not
     */
    public boolean deleteItem(Item item) {
        // Get a writeable instance of the database
        SQLiteDatabase db = getWritableDatabase();

        // Delete the item matching the given item's ID
        int rowsDeleted = db.delete(ItemContract.ItemEntry.TABLE_NAME, ItemContract.ItemEntry._ID + " = ?",
                new String[]{String.valueOf(item.getId())});

        // Check that the row was removed from the database
        return rowsDeleted > 0;
    }
}
