package com.zybooks.stockmateinventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NavUtils;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * This activity functions as the "create new" and "edit" inventory items screen.
 */
public class EditItemActivity extends AppCompatActivity {

    // The name of the key to use when sending an item to another view
    public static final String EXTRA_ITEM = "com.zybooks.stockmateinventoryapp";

    // Instance of the inventory database
    InventoryDatabaseHelper inventoryDatabaseHelper;

    // Item name and quantity views
    EditText itemName;
    EditText itemQuantity;

    // Action buttons
    Button saveBtn;
    Button deleteItemBtn;

    // The current item being edited. `null` if this is a new item not saved yet.
    private Item mItem;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set up this view's transitions
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.activity_edit_item);

        initializeViews();
        initializeDatabase();
        initializeStateFromIntent();
        initializeTextChangeListeners();
    }

    private void initializeViews() {
        itemName = findViewById(R.id.editItemName);
        itemQuantity = findViewById(R.id.editQuantity_edit);
        deleteItemBtn = findViewById(R.id.deleteItemBtn);
        saveBtn = findViewById(R.id.saveItem);

        deleteItemBtn.setVisibility(View.GONE);
        saveBtn.setEnabled(false);
    }

    private void initializeDatabase() {
        inventoryDatabaseHelper = InventoryDatabaseHelper.getInstance(this);
    }

    private void initializeStateFromIntent() {
        Item item = (Item) getIntent().getSerializableExtra(EXTRA_ITEM);
        if (item != null) {
            mItem = item;
            itemName.setText(item.getName());
            itemQuantity.setText(String.valueOf(item.getQuantity()));
            deleteItemBtn.setVisibility(View.VISIBLE);
        } else {
            itemQuantity.setText("0");
        }
    }

    private void initializeTextChangeListeners() {
        itemName.addTextChangedListener(textWatcher);
        itemQuantity.addTextChangedListener(textWatcher);
    }


    /**
     * Listen for text changes on the item name and quantity fields and set the save button
     * to enabled or disabled based on whether there is text in the item name field or not.
     */
    private final TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
            saveBtn.setEnabled(!getCurrentItemName().isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    /**
     * Save an item to the database (insert or update)
     *
     * @param view Instance of the current view
     */
    public void onSaveItemButtonClick(View view) {
        String itemName = getCurrentItemName();
        int itemQuantity = getCurrentItemQuantity();

        if (itemName.isEmpty() || itemQuantity < 0) {
            Toast.makeText(EditItemActivity.this, R.string.invalid_login, Toast.LENGTH_SHORT).show();
            return;
        }

        boolean saved;
        if (mItem != null) {
            mItem.setName(itemName);
            mItem.setQuantity(itemQuantity);
            saved = inventoryDatabaseHelper.updateItem(mItem);
        } else {
            saved = inventoryDatabaseHelper.addInventoryItem(itemName, itemQuantity);
        }

        if (saved) {
            NavUtils.navigateUpFromSameTask(this);
        } else {
            Toast.makeText(EditItemActivity.this, R.string.save_error, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Handle deleting the current item if we're editing an existing one.
     *
     * @param view Instance of the current view
     */
    public void onDeleteItemButtonClick(View view) {
        displayDeleteConfirmationDialog();
    }

    /**
     * Show a confirmation dialog before deleting the item
     */
    private void displayDeleteConfirmationDialog() {
        new AlertDialog.Builder(this).setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle(R.string.delete_confirmation_title).setMessage(R.string.delete_confirmation)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteCurrentItem();
                    }
                }).setNegativeButton("No", null).show();
    }

    /**
     * Delete the selected item and navigate back if successful
     */
    private void deleteCurrentItem() {
        boolean deleted = inventoryDatabaseHelper.deleteItem(mItem);
        finish();

        if (deleted) {
            NavUtils.navigateUpFromSameTask(EditItemActivity.this);
        } else {
            Toast.makeText(EditItemActivity.this, R.string.delete_error, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Increase the item's quantity by one.
     *
     * @param view Instance of the current view
     */
    public void onIncrementQuantityButtonClick(View view) {
        itemQuantity.setText(String.valueOf(getCurrentItemQuantity() + 1));
    }

    /**
     * Decrease the item's quantity by one - stopping at zero.
     *
     * @param view Instance of the current view
     */
    public void onDecrementQuantityButtonClick(View view) {
        itemQuantity.setText(String.valueOf(Math.max(0, getCurrentItemQuantity() - 1)));
    }

    /**
     * Helper method to get current item's name from the text field.
     *
     * @return The item's name
     */
    private String getCurrentItemName() {
        Editable name = itemName.getText();
        return name != null ? name.toString().trim() : "";
    }

    /**
     * Helper method to get the current item's quantity by parsing the integer from the text field.
     *
     * @return The item's quantity
     */
    private int getCurrentItemQuantity() {
        String rawValue = itemQuantity.getText().toString().replaceAll("[^\\d.]", "").trim();
        int quantity = rawValue.isEmpty() ? 0 : Integer.parseInt(rawValue);

        // Quantity cannot be less than 0
        return Math.max(quantity, 0);
    }
}
