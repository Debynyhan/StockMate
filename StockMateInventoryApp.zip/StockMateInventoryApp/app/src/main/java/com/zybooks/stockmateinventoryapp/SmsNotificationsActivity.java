package com.zybooks.stockmateinventoryapp;

import android.Manifest;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.List;

public class SmsNotificationsActivity extends AppCompatActivity {

    private static final String TAG = "SmsNotificationsActivity";

    private static final String PREFERENCE_RECEIVE_NOTIFICATIONS = "pref_receive_notifications";

    private static final int REQUEST_SEND_SMS_CODE = 0;

    private SwitchMaterial notificationsToggle;

    private SharedPreferences sharedPrefs;

    private boolean receiveNotifications = false;

    InventoryDatabaseHelper inventoryDatabaseHelper;

    private long currentUserId;

    private final CompoundButton.OnCheckedChangeListener toggleListener = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            receiveNotifications = isChecked;
            if (isChecked && hasPermissions()) {
                Log.d(TAG, "Wants to receive notifications");
                notificationsToggle.setChecked(true);
            } else {
                Log.d(TAG, "Does not want to receive notifications");
                notificationsToggle.setChecked(false);
                receiveNotifications = false;
            }
            savePreferences();
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.activity_sms_notification);

        inventoryDatabaseHelper = InventoryDatabaseHelper.getInstance(this);
        notificationsToggle = findViewById(R.id.notificationsToggle);
        notificationsToggle.setOnCheckedChangeListener(toggleListener);

        sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        receiveNotifications = sharedPrefs.getBoolean(PREFERENCE_RECEIVE_NOTIFICATIONS, false);

        if (receiveNotifications && hasPermissions()) {
            notificationsToggle.setChecked(true);
        }
    }

    private boolean hasPermissions() {
        String smsPermission = Manifest.permission.SEND_SMS;
        if (ContextCompat.checkSelfPermission(this, smsPermission) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, smsPermission)) {
                new AlertDialog.Builder(this)
                        .setTitle(R.string.sms_notification_dialog_title)
                        .setMessage(R.string.sms_notification_justification)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ActivityCompat.requestPermissions(SmsNotificationsActivity.this,
                                        new String[]{smsPermission}, REQUEST_SEND_SMS_CODE);
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .create()
                        .show();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{smsPermission}, REQUEST_SEND_SMS_CODE);
            }
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_SEND_SMS_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "Permission granted");
                receiveNotifications = true;
                notificationsToggle.setChecked(true);
            } else {
                Log.d(TAG, "Permission denied");
                receiveNotifications = false;
                notificationsToggle.setChecked(false);

                // Get the root view of the activity_inventory_list.xml layout
                View rootView = findViewById(android.R.id.content);

                // Show snackbar message when permission is denied
                Snackbar snackbar = Snackbar.make(rootView,
                        R.string.sms_notification_dialog_title, Snackbar.LENGTH_LONG);
                snackbar.show();
            }
            savePreferences();
        }
    }

    /**
     * Check item quantities to send Snackbar messages when the quantity reaches 0
//     */
    private void checkItemQuantities() {
        List<Item> items = inventoryDatabaseHelper.getAllInventoryItems();
        for (Item item : items) {
            if (item.getQuantity() == 0) {
                Snackbar.make(findViewById(android.R.id.content),
                        item.getName() + " has reached 0 quantity", Snackbar.LENGTH_LONG).show();
            }
        }
    }


    /**
     * Save the user's preference for receiving notifications
     */
    private void savePreferences() {
        SharedPreferences.Editor editor = sharedPrefs.edit();
        editor.putBoolean(PREFERENCE_RECEIVE_NOTIFICATIONS, receiveNotifications);
        editor.apply();
        if (receiveNotifications) {
            checkItemQuantities();
        }
    }
}
