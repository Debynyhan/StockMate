package com.zybooks.stockmateinventoryapp;

import android.provider.BaseColumns;

public class ItemContract {

    private ItemContract() {};
    public static final class ItemEntry implements BaseColumns {
        public static final String TABLE_NAME = "Inventory";
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_QUANTITY = "quantity";
        public static final String CREATE_INVENTORY_TABLE =
                "CREATE TABLE " + TABLE_NAME + " (" +
                        _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_NAME + " TEXT, " +
                        COLUMN_QUANTITY + " INTEGER)";
    }
}
