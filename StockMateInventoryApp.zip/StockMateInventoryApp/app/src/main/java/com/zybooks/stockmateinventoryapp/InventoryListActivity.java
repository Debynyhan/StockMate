package com.zybooks.stockmateinventoryapp;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.util.List;

public class InventoryListActivity extends AppCompatActivity {

    // Logcat tag
    private static final String TAG = "InventoryList";

    // List of all inventory items
    private List<Item> mItemList;

    // Instance of the app database
    InventoryDatabaseHelper inventoryDatabaseHelper;

    // View elements
    RecyclerView itemListView;
    TextView emptyListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        setContentView(R.layout.activity_inventory_list);

        initializeInventoryDatabase();
        setupInventoryRecyclerView();
        toggleEmptyInventoryMessage();
    }

    private void initializeInventoryDatabase() {
        inventoryDatabaseHelper = InventoryDatabaseHelper.getInstance(getApplicationContext());
        mItemList = inventoryDatabaseHelper.getAllInventoryItems();
    }

    private void setupInventoryRecyclerView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        itemListView = findViewById(R.id.itemListView);
        itemListView.setLayoutManager(layoutManager);
        addDividerToRecyclerView(itemListView);

        emptyListView = findViewById(R.id.emptyListView);

        ItemAdapter adapter = new ItemAdapter(mItemList, this, inventoryDatabaseHelper);
        observeAdapterDataChanges(adapter);
        itemListView.setAdapter(adapter);
    }

    private void addDividerToRecyclerView(RecyclerView recyclerView) {
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(),
                LinearLayoutManager.VERTICAL);
        recyclerView.addItemDecoration(dividerItemDecoration);
    }

    private void observeAdapterDataChanges(ItemAdapter adapter) {
        adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                toggleEmptyInventoryMessage();
            }
        });
    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Show the app bar menu
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add_item:
                openEditItemActivity();
                return true;

            case R.id.action_toggle_notifications:
                openSmsNotificationsActivity();
                return true;

            case R.id.action_logout:
                signOutAndReturnToLogin();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void openEditItemActivity() {
        Log.d(TAG, "New item view");
        Intent intent = new Intent(getApplicationContext(), EditItemActivity.class);
        startActivity(intent);
    }

    private void openSmsNotificationsActivity() {
        Log.d(TAG, "SMS Notifications view");
        Intent intent = new Intent(getApplicationContext(), SmsNotificationsActivity.class);
        startActivity(intent);
    }

    private void signOutAndReturnToLogin() {
        Log.d(TAG, "Logging out");
        Intent intent = new Intent(getApplicationContext(), UserAuthenticationActivity.class);
        startActivity(intent);
    }


    /**
     * Set the child views to visible or hidden depending on if there are items in the list or not
     */
    public void toggleEmptyInventoryMessage() {
        Log.d(TAG, "Inventory size: " + mItemList.size());
        if (mItemList.isEmpty()) {
            itemListView.setVisibility(View.GONE);
            emptyListView.setVisibility(View.VISIBLE);
        } else {
            itemListView.setVisibility(View.VISIBLE);
            emptyListView.setVisibility(View.GONE);
        }
    }
}
