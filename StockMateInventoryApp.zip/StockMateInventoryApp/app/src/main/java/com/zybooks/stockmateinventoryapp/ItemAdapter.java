package com.zybooks.stockmateinventoryapp;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {

    // Logcat tag
    private static final String TAG = "ItemAdapter";

    // Collection of inventory items in this list/adapter
    private List<Item> mItems;

    // A context that this item adapter is running in
    private Context mCtx;

    // An instance of the app's database
    InventoryDatabaseHelper inventoryDatabaseHelper;

    public ItemAdapter(List<Item> items, Context ctx, InventoryDatabaseHelper inventoryDb) {
        mItems = items;
        mCtx = ctx;
        inventoryDatabaseHelper = inventoryDb;
    }

    @Override
    public ItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.inventory_item, parent, false);
        return new ItemHolder(view, inventoryDatabaseHelper);
    }

    @Override
    public void onBindViewHolder(ItemHolder holder, int position) {
        Item item = mItems.get(position);
        holder.bind(item);
        // Set the click listener for the item actions button
        holder.setItemActionsBtnClickListener(v -> displayItemActionPopupMenu(holder, position, item));
    }

    private void displayItemActionPopupMenu(ItemHolder holder, int position, Item item) {
        PopupMenu popup = new PopupMenu(mCtx, holder.mItemActionsBtn);
        popup.inflate(R.menu.item_actions_menu);
        popup.setOnMenuItemClickListener(menuItem -> processPopupMenuAction(menuItem, position, item));
        popup.show();
    }

    @SuppressLint("NonConstantResourceId")
    private boolean processPopupMenuAction(MenuItem menuItem, int position, Item item) {
        switch (menuItem.getItemId()) {
            case R.id.menu_edit:
                launchEditItemActivity(item);
                return true;
            case R.id.menu_remove:
                displayDeleteConfirmationDialog(item, position);
                return true;
            default:
                return false;
        }
    }

    private void launchEditItemActivity(Item item) {
        Intent intent = new Intent(mCtx, EditItemActivity.class);
        intent.putExtra(EditItemActivity.EXTRA_ITEM, item);
        mCtx.startActivity(intent);
    }


    private void displayDeleteConfirmationDialog(Item item, int position) {
        new AlertDialog.Builder(mCtx).setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle(R.string.delete_confirmation_title).setMessage(R.string.delete_confirmation)
                .setPositiveButton("Yes", (dialog, which) -> deleteItem(item, position))
                .setNegativeButton("No", null).show();
    }

    private void deleteItem(Item item, int position) {
        boolean deleted = inventoryDatabaseHelper.deleteItem(item);
        if (deleted) {
            mItems.remove(position);
            notifyItemRemoved(position);
            notifyDataSetChanged();
        } else {
            Toast.makeText(mCtx, R.string.delete_error, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public int getItemCount() {
        return mItems.size();
    }
}
